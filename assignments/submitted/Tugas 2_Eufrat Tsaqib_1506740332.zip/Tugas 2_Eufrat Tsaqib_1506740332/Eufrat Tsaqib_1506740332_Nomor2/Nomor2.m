clear all
close
clc

a=150
b=160

w=bisection(a, b)