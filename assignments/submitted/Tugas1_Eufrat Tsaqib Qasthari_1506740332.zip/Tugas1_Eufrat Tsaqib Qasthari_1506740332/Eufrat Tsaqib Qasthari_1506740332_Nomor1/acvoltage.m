function Vt = acvoltage(V, omega, t);
    Vt = V * sin(omega * t);
end