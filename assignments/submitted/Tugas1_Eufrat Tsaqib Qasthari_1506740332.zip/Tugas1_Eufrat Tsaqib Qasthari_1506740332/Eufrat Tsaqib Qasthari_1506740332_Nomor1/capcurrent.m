function I = capcurrent(E, f, C);
    I = E * ( 2 * pi * f * C);
end