%%file findinverse.m
function [E,P,S,Inverse] = findinverse(A)

[m,n] = size(A);
if (m ~= n)
    display('Matriks harus matriks square')
    return
else
end
x = 1;
for j = 1:1:n-1,
    for i = j+1:1:m,
        E(:,:,x) = eye(n);
        E(i,j,x) = -A(i,j) / A(j,j);
        A = E(:,:,x) * A;
        x = x + 1;
    end
end
x = 1;
for j = n:-1:2,
    for i = j-1:-1:1,
        P(:,:,x) = eye(n);
        P(i,j,x) = -A(i,j) / A(j,j);
        A = P(:,:,x) * A;
        x = x + 1;
    end
end
for i = 1:1:n,
    S(:,:,i) = eye(n);
    S(i,i,i) = 1 / A(i,i);
    A = S(:,:,i) * A;
end

ProdE = 1;
[~,~,c] = size(E);
for ii = c:-1:1,
    ProdE = ProdE * E(:,:,ii);
end
ProdP = 1;
[~,~,c] = size(P);
for ii = c:-1:1,
    ProdP = ProdP * P(:,:,ii);
end
ProdS = 1;
[~,~,d] = size(S);
for jj = d:-1:1,
    ProdS = ProdS * S(:,:,jj);
end
Inverse = ProdS*ProdP*ProdE;
end