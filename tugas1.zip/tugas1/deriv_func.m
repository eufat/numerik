function Y = deriv_func(x)

Y = 6*x + 7;