function D = deriv_fungsi(x)

D = 