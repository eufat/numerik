function Y = func(x);
Y = 3*(x.^2) + (7.*x) -6;