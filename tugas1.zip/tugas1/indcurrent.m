function I = indcurrent(E, f, L);

I = E / ( 2 * pi * f * L);